export interface catType{
    img: string;
    fact:string;
}